﻿using System;
using TimeConverter.Service;

namespace TimeConverter
{
    /// <summary>
    /// Program to convert time to human readbale format
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Final output parameter to return
        /// </summary>
        private static string timeToWord = string.Empty;
        static void Main(string[] args)
        {
            try
            {
                // split the arguments and assign into local variables
                string enteredTime = args[0];
                int hour = Convert.ToInt32(enteredTime.Split(':')[0]);
                int minute = Convert.ToInt32(enteredTime.Split(':')[1]);

                //create object of the class
                ITimeConverter timeConverter = new TimeConverterBO();
                // pass the parameters to  convert into readbale word format
                timeToWord = timeConverter.GetTimeInHumanFormat(hour, minute);
                Console.WriteLine("Human Readable format ->" + timeToWord);
            }
            catch 
            {
                Console.WriteLine("Provide proper input and time should be in HH:MM format");
            }
            Console.ReadKey();
        }
    }
}
