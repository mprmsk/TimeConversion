﻿namespace TimeConverter.Service
{
    interface ITimeConverter
    {
        public string GetTimeInHumanFormat(int _hour,int _minute);  
    }
}
