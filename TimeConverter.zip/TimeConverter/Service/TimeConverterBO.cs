﻿using System;

namespace TimeConverter.Service
{
    /// <summary>
    /// Class to convert from time to word
    /// </summary>
    public class TimeConverterBO : ITimeConverter
    {
        /// <summary>
        /// Used this array for words 
        /// </summary>
        public string[] words = { "zero", "one", "two", "three", "four",
                            "five", "six", "seven", "eight", "nine",
                            "ten", "eleven", "twelve", "thirteen",
                            "fourteen", "fifteen", "sixteen", "seventeen",
                            "eighteen", "nineteen", "twenty", "twenty one",
                            "twenty two", "twenty three", "twenty four",
                            "twenty five", "twenty six", "twenty seven",
                            "twenty eight", "twenty nine",
                        };
        /// <summary>
        /// Method to convert Time to Word Format.
        /// </summary>
        /// <param name="h"></param>
        /// <param name="m"></param>
        /// <returns></returns>
        public string GetTimeInHumanFormat(int _hours, int _minutes)
        {
            try
            {
                string convertedWord = string.Empty;
                

                if (_minutes == 0)
                    convertedWord = (words[_hours] + " o' clock ");

                else if (_minutes == 1)
                    convertedWord = ("one past " + words[_hours]);

                else if (_minutes == 59)
                    convertedWord = ("one to " + words[(_hours % 12) + 1]);

                else if (_minutes == 15)
                    convertedWord = ("quarter past " + words[_hours]);

                else if (_minutes == 30)
                    convertedWord = ("half past " + words[_hours]);

                else if (_minutes == 45)
                    convertedWord = ("quarter to " + words[(_hours % 12) + 1]);

                else if (_minutes <= 30)
                    convertedWord = (words[_minutes] + " past " + words[_hours]);

                else if (_minutes > 30)
                    convertedWord = (words[60 - _minutes] + " to " + words[(_hours % 12) + 1]);

                return convertedWord;
            }
            catch (Exception)
            {
                throw;
            }


        }

        // Methods to test will go here     
    }
}
